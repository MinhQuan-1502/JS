function toggleDropdown(id) {
  const submenu = document.getElementById(id);
  const allSubmenus = document.querySelectorAll(".submenu");

  allSubmenus.forEach((menu) => {
    if (menu !== submenu) {
      menu.style.display = "none";
    }
  });

  const isVisible = window.getComputedStyle(submenu).display === "block";

  if (isVisible) {
    submenu.style.display = "none";
  } else {
    submenu.style.display = "block";
  }
}

document.addEventListener("click", function (event) {
  const isDropdown = event.target.closest(".dropdown-menu");
  if (!isDropdown) {
    document.querySelectorAll(".submenu").forEach((menu) => {
      menu.style.display = "none";
    });
  }
});

function logoutBtn() {
  fetch("/logout")
    .then(() => {
      window.location.href = "/LoginPage";
    })
    .catch((err) => {
      console.error("Lỗi logout:", err);
    });
}
