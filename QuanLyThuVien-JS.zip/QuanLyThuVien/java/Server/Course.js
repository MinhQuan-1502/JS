const mongoose = require('mongoose');

const courseSchema = new mongoose.Schema({
  Code: {type: String,required: true},
  CourseTitle:{type: String,required: true}
});
module.exports = mongoose.model('Course', courseSchema);
