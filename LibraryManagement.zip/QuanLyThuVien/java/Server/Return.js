const mongoose = require("mongoose");

const returnBookSchema = new mongoose.Schema({
  borrowId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "BorrowBook",
    required: true,
  },
  date: { type: Date, default: Date.now },
  studentId: {
    type: String,
    required: true,
  },
  bookId: { type: mongoose.Schema.Types.ObjectId, ref: "Book", required: true },
});

module.exports = mongoose.model("ReturnBook", returnBookSchema);
