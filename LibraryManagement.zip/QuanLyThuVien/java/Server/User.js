// Kiểm tra phần tử và thêm event listener an toàn
function safeAddEventListener(id, event, handler) {
  const el = document.getElementById(id);
  if (el) el.addEventListener(event, handler);
}

// Render bảng sách khả dụng
function renderBooks(books) {
  const tbody = document.querySelector("#booksTable tbody");
  if (!tbody) return; // Nếu không có tbody thì không làm gì

  tbody.innerHTML = "";

  books
    .filter((book) => book.status === "available")
    .forEach((book) => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${book.isbn}</td>
        <td>${book.title}</td>
        <td><button class="borrowBtn" data-id="${book._id}" data-isbn="${book.isbn}" data-title="${book.title}">Mượn</button></td>
      `;
      tbody.appendChild(tr);
    });

  document.querySelectorAll(".borrowBtn").forEach((btn) => {
    btn.addEventListener("click", () => openBorrowDialog(btn.dataset));
  });
}

// Load sách khả dụng từ API
async function loadAvailableBooks() {
  try {
    const res = await fetch("/api/books");
    if (!res.ok) throw new Error("Lỗi tải sách");
    const books = await res.json();
    renderBooks(books);
  } catch (err) {
    alert("Lỗi tải danh sách sách");
    console.error(err);
  }
}

// Tìm kiếm sách theo query
async function searchBooks(query) {
  try {
    const res = await fetch(`/search?q=${encodeURIComponent(query)}`);
    if (!res.ok) {
      const text = await res.text();
      console.error("Server error:", text);
      return;
    }
    const books = await res.json();
    renderBooks(books);
  } catch (err) {
    console.error("Error searching for books:", err);
  }
}

// Mở dialog mượn sách, điền dữ liệu sách
function openBorrowDialog(bookData) {
  const dialog = document.getElementById("borrowDialog");
  if (!dialog) return;

  dialog.showModal();

  const bookISBN = document.getElementById("bookISBN");
  const bookTitle = document.getElementById("bookTitle");
  const bookId = document.getElementById("bookId");
  const studentIdInput = document.getElementById("studentId");
  const dateInput = document.getElementById("date");

  if (bookISBN) bookISBN.value = bookData.isbn;
  if (bookTitle) bookTitle.value = bookData.title;
  if (bookId) bookId.value = bookData.id;

  if (studentIdInput) {
    if (studentIdInput.value.trim() !== "") {
      studentIdInput.readOnly = true;
    } else {
      studentIdInput.readOnly = false;
    }
  }

  if (dateInput) {
    dateInput.value = new Date().toISOString().split("T")[0];
  }
}

// Load thông tin sinh viên hiện tại
async function loadCurrentStudent() {
  try {
    const res = await fetch("/api/currentStudent");
    if (!res.ok) throw new Error("Chưa đăng nhập");
    const data = await res.json();

    const studentIdInput = document.getElementById("studentId");
    const studentNameDisplay = document.getElementById("studentNameDisplay");

    if (studentIdInput && data.student_id) {
      studentIdInput.value = data.student_id;
    }
    if (studentNameDisplay && data.first_name && data.last_name) {
      studentNameDisplay.innerText = data.first_name + " " + data.last_name;
    }
  } catch (err) {
    console.warn("Chưa đăng nhập hoặc lỗi khi lấy thông tin sinh viên:", err);

    const studentIdInput = document.getElementById("studentId");
    const studentNameDisplay = document.getElementById("studentNameDisplay");

    if (studentIdInput) studentIdInput.value = "";
    if (studentNameDisplay) studentNameDisplay.innerText = "Chưa đăng nhập";
  }
}

// Xử lý submit form mượn sách an toàn
function setupBorrowForm() {
  const borrowForm = document.getElementById("borrowForm");
  if (!borrowForm) return;

  borrowForm.addEventListener("submit", async (e) => {
    e.preventDefault();

    const bookId = document.getElementById("bookId")?.value;
    const studentId = document.getElementById("studentId")?.value;
    const date = document.getElementById("date")?.value;

    if (!bookId || !studentId || !date) {
      alert("Vui lòng điền đầy đủ thông tin mượn sách.");
      return;
    }

    try {
      const res = await fetch("/AddBorrowBook", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ bookId, studentId, date }),
      });

      if (res.ok) {
        alert("Mượn sách thành công!");
        document.getElementById("borrowDialog")?.close();
        if (typeof loadAvailableBooks === "function") {
          loadAvailableBooks();
        }
      } else {
        const errData = await res.json();
        alert("Lỗi: " + (errData.error || "Không xác định"));
      }
    } catch (err) {
      console.error(err);
      alert("Lỗi server khi mượn sách");
    }
  });
}

// Xử lý nút hủy dialog mượn sách
function setupCancelButton() {
  const cancelBtn = document.getElementById("cancelBtn");
  if (!cancelBtn) return;

  cancelBtn.addEventListener("click", () => {
    document.getElementById("borrowDialog")?.close();
  });
}

// Xử lý tìm kiếm sách an toàn
function setupSearchInput() {
  const searchInput = document.getElementById("searchinput");
  if (!searchInput) return;

  searchInput.addEventListener("input", (e) => {
    const query = e.target.value.trim();
    if (query === "") {
      if (typeof loadAvailableBooks === "function") loadAvailableBooks();
    } else {
      searchBooks(query);
    }
  });
}

// Xử lý logout
function logoutBtn() {
  fetch("/logout")
    .then(() => {
      window.location.href = "/LoginPage";
    })
    .catch((err) => {
      console.error("Lỗi logout:", err);
    });
}

// Hàm khởi tạo gọi khi load trang
function initPage() {
  loadCurrentStudent();
  loadAvailableBooks();
  setupBorrowForm();
  setupCancelButton();
  setupSearchInput();
  setupLogoutBtn();
}

// Chỉ chạy initPage khi DOM đã sẵn sàng
window.addEventListener("DOMContentLoaded", initPage);
