const express = require("express");
const bodyParser = require("body-parser");
const path = require("path");
const fs = require("fs");
require("./ConnectDTB");
const Categories = require("./Categories");
const Book = require("./Book");
const Course = require("./Course");
const Student = require("./Student");
const BorrowBook = require("./BorrowBook");
const ReturnBook = require("./Return");
const validator = require("validator");
const nodemailer = require("nodemailer");
//const Member = require("./Student");
const mongoose = require("mongoose");
const session = require("express-session");

const app = express();
app.use(express.json());
const PORT = 3000;

app.use(bodyParser.urlencoded({ extended: true }));
app.use("/assets", express.static(path.join(__dirname, "../assets")));
app.use("/Page", express.static(path.join(__dirname, "../Page")));
app.use("/Server", express.static(path.join(__dirname)));
app.use("/Page", express.static(path.join(__dirname, "..", "Page")));
app.use(
  session({
    secret: "secret-key-random-you-should-change",
    resave: false,
    saveUninitialized: false,
    cookie: { maxAge: 1000 * 60 * 60 * 24 },
  })
);

app.use((req, res, next) => {
  console.log("Session:", req.session);
  next();
});

app.get("/", (req, res) => {
  res.sendFile(
    path.join(__dirname, "..", "Page", "Authentication", "LoginPage.html")
  );
});

//Categories
app.get("/CategoriesPage", (req, res) => {
  res.sendFile(path.join(__dirname, "..", "Page", "Book", "Categories.html"));
});

app.get("/AddCategoriesPage", (req, res) => {
  res.sendFile(
    path.join(__dirname, "..", "Page", "Book", "AddCategories.html")
  );
});

app.post("/AddCategories", async (req, res) => {
  const categoriesName = req.body.categories;

  try {
    const newCategory = new Categories({ categories: categoriesName });
    await newCategory.save();
    res.redirect("/CategoriesPage");
  } catch (err) {
    console.error("❌ Chi tiết lỗi:", err);

    res.status(500).send("Lỗi khi thêm thể loại: " + err.message);
  }
});

app.delete("/DeleteCategory/:id", async (req, res) => {
  const categoryId = req.params.id;

  try {
    // Lấy category cần xóa
    const category = await Categories.findById(categoryId);
    if (!category) {
      return res.status(404).send("Không tìm thấy thể loại");
    }

    // Kiểm tra có sách thuộc category này không
    const booksCount = await Book.countDocuments({
      $or: [{ category: category._id }, { category: category.categories }],
    });

    if (booksCount > 0) {
      return res
        .status(400)
        .send("Không thể xóa thể loại vì có sách thuộc thể loại này");
    }

    // Nếu không có sách thì xóa
    await Categories.findByIdAndDelete(categoryId);
    res.status(200).send("Xóa thể loại thành công");
  } catch (err) {
    console.error("Lỗi khi xóa thể loại:", err);
    res.status(500).send("Lỗi khi xóa thể loại");
  }
});
app.get("/api/category/:id", async (req, res) => {
  try {
    const category = await Categories.findById(req.params.id).lean();
    if (!category) {
      return res.status(404).json({ error: "Category không tồn tại" });
    }
    res.json(category);
  } catch (err) {
    console.error("Lỗi lấy category:", err);
    res.status(500).json({ error: "Lỗi server" });
  }
});
app.post("/UpdateCategory/:id", async (req, res) => {
  const id = req.params.id;
  const { Categories: newCategoryName } = req.body;

  try {
    const updated = await Categories.findByIdAndUpdate(
      id,
      { categories: newCategoryName },
      { new: true, runValidators: true }
    );
    if (!updated) {
      return res.status(404).send("Không tìm thấy thể loại để cập nhật");
    }
    res.redirect("/CategoriesPage"); // Hoặc trang bạn muốn sau khi cập nhật
  } catch (err) {
    console.error("Lỗi khi cập nhật thể loại:", err);
    res.status(500).send("Lỗi khi cập nhật thể loại");
  }
});
app.get("/UpdateCategoryPage", (req, res) => {
  res.sendFile(
    path.join(__dirname, "..", "Page", "Book", "UpdateCategory.html")
  );
});

//Book
app.get("/BookListPage", (req, res) => {
  res.sendFile(path.join(__dirname, "..", "Page", "Book", "BookList.html"));
});

app.get("/AddBookPage", (req, res) => {
  res.sendFile(path.join(__dirname, "..", "Page", "Book", "AddBook.html"));
});

app.get("/api/categories", async (req, res) => {
  try {
    const categories = await Categories.find({}, "categories").lean();
    res.json(categories); // Trả về mảng [{Categories: "Kinh dị"}, ...]
  } catch (err) {
    console.error("Lỗi lấy danh sách categories:", err);
    res.status(500).json({ error: "Lỗi khi lấy danh sách categories" });
  }
});

app.post("/AddBook", async (req, res) => {
  const { category, isbn, title, author, publisher, status } = req.body;

  try {
    const newBook = new Book({
      category,
      isbn,
      title,
      author,
      publisher,
      status,
    });
    await newBook.save();
    res.redirect("/Page/Book/BookList.html");
  } catch (err) {
    console.error("Lỗi khi thêm sách:", err);
    res.status(500).send("Lỗi khi thêm sách.");
  }
});

app.get("/api/books", async (req, res) => {
  try {
    const books = await Book.find({}).lean();
    res.json(books);
  } catch (err) {
    console.error("Lỗi lấy danh sách sách:", err);
    res.status(500).json({ error: "Lỗi khi lấy danh sách sách" });
  }
});

app.delete("/DeleteBook/:id", async (req, res) => {
  const bookId = req.params.id;

  try {
    const { Types } = require("mongoose");

    // Nếu bookId không hợp lệ thì trả về lỗi luôn
    if (!Types.ObjectId.isValid(bookId)) {
      return res.status(400).send("ID sách không hợp lệ");
    }

    const bookObjectId = new Types.ObjectId(bookId);

    const book = await Book.findById(bookObjectId);
    if (!book) {
      return res.status(404).send("Không tìm thấy sách");
    }

    console.log("book:", book);

    if (book.status !== "available") {
      return res.status(400).send("Sách đang được mượn");
    }

    // ✅ Thử cả kiểu ObjectId và String
    const borrowRecord =
      (await BorrowBook.findOne({ bookId: bookObjectId })) ||
      (await BorrowBook.findOne({ bookId }));

    console.log("borrowRecord:", borrowRecord);

    // if (borrowRecord) {
    //   return res.status(400).send("Không thể xóa sách vì sách đang được mượn");
    // }

    await Book.findByIdAndDelete(bookObjectId);
    res.status(200).send("Xóa sách thành công");
  } catch (err) {
    console.error("Lỗi khi xóa sách:", err);
    res.status(500).send("Lỗi khi xóa sách");
  }
});

app.get("/UpdateBookPage", async (req, res) => {
  const bookId = req.query.id;
  if (!bookId) {
    return res.status(400).send("Thiếu ID sách");
  }

  try {
    const book = await Book.findById(bookId).lean();
    if (!book) {
      return res.status(404).send("Không tìm thấy sách");
    }

    const categories = await Categories.find({}, "categories").lean();
    const categoryOptions = categories
      .map((cat) => {
        const selected = cat.categories === book.category ? "selected" : "";
        return `<option value="${cat.categories}" ${selected}>${cat.categories}</option>`;
      })
      .join("");

    let html = fs.readFileSync(
      path.join(__dirname, "..", "Page", "Book", "UpdateBook.html"),
      "utf-8"
    );

    html = html
      .replace("{{categoryOptions}}", categoryOptions)
      .replace("{{isbn}}", book.isbn || "")
      .replace("{{title}}", book.title || "")
      .replace("{{author}}", book.author || "")
      .replace("{{publisher}}", book.publisher || "")
      .replace("{{status}}", book.status || "")
      .replace(/{{id}}/g, book._id);

    res.send(html);
  } catch (err) {
    console.error("Lỗi lấy dữ liệu sách:", err);
    res.status(500).send("Lỗi máy chủ");
  }
});

app.post("/UpdateBook", async (req, res) => {
  const { id, category, isbn, title, author, publisher, status } = req.body;
  try {
    await Book.findByIdAndUpdate(id, {
      category,
      isbn,
      title,
      author,
      publisher,
      status,
    });
    res.redirect("/BookListPage"); // Quay lại danh sách sách sau khi cập nhật
  } catch (err) {
    console.error("Lỗi khi cập nhật sách:", err);
    res.status(500).send("Lỗi khi cập nhật sách");
  }
});

//Course
app.get("/CoursePage", (req, res) => {
  res.sendFile(path.join(__dirname, "..", "Page", "Student", "Course.html"));
});

app.get("/AddCoursePage", (req, res) => {
  res.sendFile(path.join(__dirname, "..", "Page", "Student", "AddCourse.html"));
});

app.post("/AddCourse", async (req, res) => {
  const { Code, CourseTitle } = req.body;

  try {
    const newCourse = new Course({ Code, CourseTitle });
    await newCourse.save();
    res.redirect("/CoursePage");
  } catch (err) {
    console.error("Lỗi khi thêm khóa học:", err);
    res.status(500).send("Lỗi khi thêm khóa học.");
  }
});

app.delete("/DeleteCourse/:id", async (req, res) => {
  const courseId = req.params.id;
  try {
    // Kiểm tra xem có học sinh nào thuộc khóa học này không
    const count = await Student.countDocuments({ course: courseId });
    if (count > 0) {
      return res
        .status(400)
        .send("Không thể xóa khóa học vì còn học sinh thuộc khóa học này.");
    }

    // Nếu không có học sinh, mới xóa
    await Course.findByIdAndDelete(courseId);
    res.status(200).send("Xóa khóa học thành công");
  } catch (err) {
    console.error("Lỗi khi xóa khóa học:", err);
    res.status(500).send("Lỗi khi xóa khóa học");
  }
});
app.get("/UpdateCoursePage", async (req, res) => {
  res.sendFile(
    path.join(__dirname, "..", "Page", "Student", "UpdateCourse.html")
  );
});
app.get("/api/course/:id", async (req, res) => {
  try {
    const course = await Course.findById(req.params.id).lean();
    if (!course) return res.status(404).send("Không tìm thấy khóa học");
    res.json(course);
  } catch (err) {
    console.error("Lỗi lấy khóa học:", err);
    res.status(500).send("Lỗi lấy khóa học");
  }
});
app.post("/UpdateCourse/:id", async (req, res) => {
  const { Code, CourseTitle } = req.body;
  try {
    await Course.findByIdAndUpdate(req.params.id, { Code, CourseTitle });
    res.redirect("/CoursePage");
  } catch (err) {
    console.error("Lỗi cập nhật khóa học:", err);
    res.status(500).send("Lỗi cập nhật khóa học");
  }
});

//Student
app.get("/StudentListPage", (req, res) => {
  res.sendFile(
    path.join(__dirname, "..", "Page", "Student", "StudentList.html")
  );
});

app.get("/AddStudentPage", (req, res) => {
  res.sendFile(
    path.join(__dirname, "..", "Page", "Student", "AddStudent.html")
  );
});

app.get("/api/courses", async (req, res) => {
  try {
    const courses = await Course.find({}, "Code CourseTitle").lean();
    res.json(courses);
  } catch (err) {
    console.error("Lỗi lấy danh sách khóa học:", err);
    res.status(500).json({ error: "Lỗi khi lấy danh sách khóa học" });
  }
});

app.post("/AddStudent", async (req, res) => {
  const { course, student_id, first_name, last_name, e_mail, pass_word } =
    req.body;
  try {
    const student = new Student({
      course,
      student_id,
      first_name,
      last_name,
      e_mail,
      pass_word,
    });
    await student.save();
    res.redirect("/Page/Student/StudentList.html");
  } catch (err) {
    console.error("Lỗi khi thêm sinh viên:", err);

    let errorMessage = "Lỗi khi thêm sinh viên.";
    if (err.code === 11000) {
      // Duplicate key error
      if (err.keyPattern && err.keyPattern.student_id) {
        errorMessage = "Student ID đã tồn tại!";
      } else if (err.keyPattern && err.keyPattern.e_mail) {
        errorMessage = "Email đã tồn tại!";
      }
    } else if (err.errors && err.errors.e_mail && err.errors.e_mail.message) {
      // Nếu có lỗi validate email trong schema mongoose
      errorMessage = err.errors.e_mail.message;
    }

    return res.status(400).json({ error: errorMessage });
  }
});

app.get("/api/students", async (req, res) => {
  try {
    const students = await Student.find()
      .populate("course", "Code CourseTitle")
      .lean();
    res.json(students);
  } catch (err) {
    console.error("Lỗi lấy danh sách học sinh:", err);
    res.status(500).json({ error: "Lỗi khi lấy danh sách học sinh" });
  }
});

app.delete("/DeleteStudent/:id", async (req, res) => {
  try {
    await Student.findByIdAndDelete(req.params.id);
    res.sendStatus(200);
  } catch (err) {
    console.error("Lỗi xóa học sinh:", err);
    res.status(500).send("Xóa thất bại");
  }
});

app.get("/api/student/:id", async (req, res) => {
  try {
    const student = await Student.findById(req.params.id).lean();
    res.json(student);
  } catch (err) {
    console.error("Lỗi lấy thông tin học sinh:", err);
    res.status(500).send("Lỗi server");
  }
});

app.put("/UpdateStudent/:id", async (req, res) => {
  console.log("Request body:", req.body);
  try {
    const { course, student_id, first_name, last_name, e_mail, pass_word } =
      req.body;
    const studentIdToUpdate = req.params.id;

    // Validate email format
    if (typeof e_mail !== "string" || !validator.isEmail(e_mail)) {
      return res.status(400).json({ error: "Email không đúng định dạng" });
    }

    // Kiểm tra trùng student_id (ngoại trừ bản ghi đang update)
    const studentIdExists = await Student.findOne({
      student_id,
      _id: { $ne: studentIdToUpdate },
    });
    if (studentIdExists) {
      return res.status(400).json({ error: "Student ID đã tồn tại!" });
    }

    // Kiểm tra trùng email (ngoại trừ bản ghi đang update)
    const emailExists = await Student.findOne({
      e_mail,
      _id: { $ne: studentIdToUpdate },
    });
    if (emailExists) {
      return res.status(400).json({ error: "Email đã tồn tại!" });
    }

    // Nếu qua hết các bước trên thì mới update
    await Student.findByIdAndUpdate(studentIdToUpdate, {
      course,
      student_id,
      first_name,
      last_name,
      e_mail,
    });

    res.sendStatus(200);
  } catch (err) {
    console.error("Lỗi cập nhật học sinh:", err);
    res.status(500).send("Cập nhật thất bại");
  }
});

app.get("/UpdateStudentPage", (req, res) => {
  res.sendFile(
    path.join(__dirname, "..", "Page", "Student", "UpdateStudent.html")
  );
});

// API lấy thông tin sinh viên đang đăng nhập
app.get("/api/currentStudent", async (req, res) => {
  if (!req.session.studentId) {
    return res.status(401).json({ error: "Chưa đăng nhập" });
  }

  try {
    const student = await Student.findOne({
      student_id: req.session.studentId,
    }).lean();
    if (!student) {
      return res.status(404).json({ error: "Không tìm thấy sinh viên" });
    }
    res.json({
      student_id: student.student_id,
      first_name: student.first_name,
      last_name: student.last_name,
      e_mail: student.e_mail,
    });
  } catch (err) {
    console.error("Lỗi khi lấy sinh viên:", err);
    res.status(500).json({ error: "Lỗi server" });
  }
});

//Borrow book
app.get("/BorrowBookPage", async (req, res) => {
  res.sendFile(
    path.join(__dirname, "..", "Page", "BorrowBook", "BorrowBookPage.html")
  );
});

app.get("/AddBorrowBookPage", async (req, res) => {
  res.sendFile(
    path.join(__dirname, "..", "Page", "BorrowBook", "AddBorrowBookPage.html")
  );
});
app.post("/AddBorrowBook", async (req, res) => {
  const { date, studentId, bookId } = req.body;

  if (!date || !studentId || !bookId) {
    return res.status(400).send("Thiếu thông tin bắt buộc");
  }

  try {
    // Kiểm tra sách còn status available không
    const book = await Book.findById(bookId);
    if (!book) return res.status(404).send("Không tìm thấy sách");
    if (book.status !== "available") {
      return res.status(400).send("Sách đã được mượn, không thể mượn lại");
    }
    let student;
    if (mongoose.Types.ObjectId.isValid(studentId)) {
      // Tìm theo _id nếu hợp lệ
      student = await Student.findById(studentId);
    }
    if (!student) {
      // Nếu không tìm thấy hoặc studentId không phải ObjectId, thử tìm theo student_id (mã sinh viên)
      student = await Student.findOne({ student_id: studentId });
    }
    if (!student) {
      return res.status(404).send("Không tìm thấy sinh viên");
    }

    // Tạo phiếu mượn mới
    const newBorrow = new BorrowBook({
      date: new Date(date),
      studentId: student.student_id,
      bookId,
    });

    await newBorrow.save();

    // Cập nhật trạng thái sách thành borrowed
    book.status = "borrowed";
    await book.save();

    res.status(200).send("Mượn sách thành công");
    //res.redirect("/BorrowBookPage");
  } catch (err) {
    console.error("Lỗi khi mượn sách:", err);
    res.status(500).send("Lỗi server");
  }
});
app.get("/api/borrowBooks", async (req, res) => {
  const returnedBorrowIds = await ReturnBook.find().distinct("borrowId");

  try {
    const borrowBooks = await BorrowBook.find({
      _id: { $nin: returnedBorrowIds },
    })
      //.populate("studentId", "student_id first_name last_name")
      .populate("bookId", "isbn title")
      .lean();
    const students = await Student.find().lean();

    const studentMap = {};
    students.forEach((s) => {
      studentMap[s.student_id] = s;
    });

    // Gắn thông tin sinh viên tương ứng
    // const result = borrowBooks.map((borrow) => ({
    //   ...borrow,
    //   studentInfo: borrow.studentId
    //     ? {
    //         student_id: borrow.studentId.student_id,
    //         first_name: borrow.studentId.first_name,
    //         last_name: borrow.studentId.last_name,
    //       }
    //     : {
    //         student_id: "",
    //         first_name: "",
    //         last_name: "",
    //       },
    // }));

    const result = borrowBooks.map((borrow) => ({
      ...borrow,
      studentInfo: studentMap[borrow.studentId] || {
        student_id: "",
        first_name: "",
        last_name: "",
      },
    }));

    res.json(result);
  } catch (err) {
    console.error("Lỗi lấy danh sách lượt mượn:", err);
    res.status(500).json({ error: "Lỗi server" });
  }
});

app.post("/api/borrowBooks/:borrowId/return", async (req, res) => {
  try {
    const borrowId = req.params.borrowId;

    const borrow = await BorrowBook.findById(borrowId);
    if (!borrow) return res.status(404).send("Không tìm thấy lượt mượn");

    const alreadyReturned = await ReturnBook.findOne({ borrowId });
    if (alreadyReturned) return res.status(400).send("Sách đã được trả rồi");

    await ReturnBook.create({
      borrowId,
      studentId: borrow.studentId,
      bookId: borrow.bookId,
      date: new Date(),
    });

    await Book.findByIdAndUpdate(borrow.bookId, {
      $inc: { available: 1 },
      status: "available",
    });

    res.send("Trả sách thành công");
  } catch (error) {
    console.error(error);
    res.status(500).send("Lỗi khi trả sách");
  }
});
//Dashboard
app.get("/api/dashboard", async (req, res) => {
  try {
    const borrowStats = await BorrowBook.aggregate([
      {
        $group: {
          _id: { $month: "$date" },
          count: { $sum: 1 },
        },
      },
      { $sort: { _id: 1 } },
    ]);

    const returnStats = await ReturnBook.aggregate([
      {
        $group: {
          _id: { $month: "$date" },
          count: { $sum: 1 },
        },
      },
      { $sort: { _id: 1 } },
    ]);

    res.json({ borrow: borrowStats, return: returnStats });
  } catch (err) {
    console.error("❌ Dashboard error:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

//Summary in dashboard
app.get("/api/dashboard/summary", async (req, res) => {
  try {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const totalBooks = await Book.countDocuments();

    const totalMembers = await Student.countDocuments();
    const borrowToday = await BorrowBook.countDocuments({
      date: { $gte: today },
    });
    const returnToday = await ReturnBook.countDocuments({
      date: { $gte: today },
    });
    res.json({
      totalBooks,
      totalMembers,
      borrowToday,
      returnToday,
    });
  } catch (err) {
    console.error("❌ Dashboard summary error:", err);
    res.status(500).json({ error: err.message });
  }
});

//Login
app.get("/VerifyOTP", (req, res) => {
  res.sendFile(
    path.join(__dirname, "..", "Page", "Authentication", "VerifyOTP.html")
  );
});
app.post("/login", async (req, res) => {
  const { student_id, pass_word } = req.body;

  if (student_id === "admin" && pass_word === "123456") {
    return res.redirect("/Page/home.html");
  }

  try {
    const student = await Student.findOne({ student_id, pass_word });

    if (!student) {
      return res.redirect("/LoginPage?error=1");
    }

    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    req.session.tempStudentId = student.student_id;
    req.session.otp = otp;
    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: "ht127392@gmail.com",
        pass: "cark gkwu zwew dbwu",
      },
    });

    const mailOptions = {
      from: "ht127392@gmail.com",
      to: student.e_mail,
      subject: "Your OTP Code",
      text: `Your OTP code is: ${otp}`,
    };

    await transporter.sendMail(mailOptions);

    // Dùng script để set localStorage và chuyển đến trang xác minh OTP
    res.send(`
      <script>
        localStorage.setItem("student_id", "${student_id}");
        localStorage.setItem("correct_otp", "${otp}");
        window.location.href = "/VerifyOTP";
      </script>
    `);
  } catch (err) {
    console.error("Login error:", err);
    res.status(500).send("Internal server error");
  }
});

app.post("/verify-otp", (req, res) => {
  const { student_id, correct_otp, entered_otp } = req.body;

  if (!req.session.otp || !req.session.tempStudentId) {
    return res.redirect("/VerifyOTP?error=1");
  }

  if (req.session.otp === entered_otp) {
    req.session.studentId = req.session.tempStudentId;

    delete req.session.otp;
    delete req.session.tempStudentId;

    res.redirect("/Page/homeforuser.html");
  } else {
    // Nếu sai OTP, chuyển về trang VerifyOTP.html và thêm query `error=1`
    res.redirect("/VerifyOTP?error=1");
  }
});
app.get("/LoginPage", (req, res) => {
  res.sendFile(
    path.join(__dirname, "..", "Page", "Authentication", "LoginPage.html")
  );
});
app.get("/RegisterPage", (req, res) => {
  res.sendFile(
    path.join(__dirname, "..", "Page", "Authentication", "RegisterPage.html")
  );
});
const otpStore = new Map(); // Lưu tạm thông tin đăng ký và otp, dạng {student_id: {otp, data, expiresAt}}

const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: "ht127392@gmail.com", // thay bằng email của bạn
    pass: "cark gkwu zwew dbwu", // thay bằng mật khẩu app hoặc password email
  },
});

// API gửi OTP khi đăng ký
app.post("/register/send-otp", async (req, res) => {
  const { course, student_id, first_name, last_name, e_mail, pass_word } =
    req.body;

  if (
    !course ||
    !student_id ||
    !first_name ||
    !last_name ||
    !e_mail ||
    !pass_word
  ) {
    return res.status(400).json({ error: "Thiếu dữ liệu bắt buộc." });
  }

  // Kiểm tra định dạng email
  if (!validator.isEmail(e_mail)) {
    return res.status(400).json({ error: "Email không hợp lệ." });
  }

  // Kiểm tra tồn tại student_id hoặc email trong DB
  const existsStudent = await Student.findOne({
    $or: [{ student_id }, { e_mail }],
  });
  if (existsStudent) {
    return res
      .status(400)
      .json({ error: "Mã sinh viên hoặc email đã tồn tại." });
  }

  // Tạo OTP ngẫu nhiên 6 số
  const otp = Math.floor(100000 + Math.random() * 900000).toString();

  // Lưu tạm dữ liệu đăng ký và OTP trong 5 phút
  otpStore.set(student_id, {
    otp,
    data: { course, student_id, first_name, last_name, e_mail, pass_word },
    expiresAt: Date.now() + 5 * 60 * 1000,
  });

  // Gửi email OTP
  const mailOptions = {
    from: '"Library App" <ht127392@gmail.com>',
    to: e_mail,
    subject: "Mã OTP xác nhận đăng ký",
    text: `Mã OTP của bạn là: ${otp}. Mã này có hiệu lực trong 5 phút.`,
  };

  try {
    await transporter.sendMail(mailOptions);
    res.json({ message: "Đã gửi mã OTP về email. Vui lòng kiểm tra hộp thư." });
  } catch (error) {
    console.error("Lỗi gửi email OTP:", error);
    res.status(500).json({ error: "Gửi email thất bại." });
  }
});

// API xác nhận OTP
app.post("/register/verify-otp", async (req, res) => {
  const { student_id, otp } = req.body;

  if (!student_id || !otp) {
    return res.status(400).json({ error: "Thiếu dữ liệu." });
  }

  const record = otpStore.get(student_id);
  if (!record) {
    return res
      .status(400)
      .json({ error: "Không tìm thấy mã OTP hoặc đã hết hạn." });
  }

  if (record.expiresAt < Date.now()) {
    otpStore.delete(student_id);
    return res.status(400).json({ error: "Mã OTP đã hết hạn." });
  }

  if (record.otp !== otp) {
    return res.status(400).json({ error: "Mã OTP không đúng." });
  }

  try {
    // Lưu sinh viên vào DB
    const newStudent = new Student(record.data);
    await newStudent.save();

    // Xóa dữ liệu tạm
    otpStore.delete(student_id);

    res.json({ message: "Đăng ký thành công!" });
  } catch (err) {
    console.error("Lỗi khi lưu sinh viên:", err);
    res.status(500).json({ error: "Lỗi khi lưu sinh viên." });
  }
});
app.get("/VerifyOTPRegister", (req, res) => {
  res.sendFile(
    path.join(
      __dirname,
      "..",
      "Page",
      "Authentication",
      "VerifyOTPRegister.html"
    )
  );
});
app.get("/ForgotPasswordPage", (req, res) => {
  res.sendFile(
    path.join(
      __dirname,
      "..",
      "Page",
      "Authentication",
      "ForgotPasswordPage.html"
    )
  );
});
const otpStorage = new Map();
app.post("/forgot-password", async (req, res) => {
  const { student_id } = req.body;
  try {
    const student = await Student.findOne({ student_id });
    if (!student) {
      return res.status(400).send("Student ID không tồn tại.");
    }

    // Tạo OTP ngẫu nhiên 6 số
    const otp = Math.floor(100000 + Math.random() * 900000).toString();

    // Lưu OTP với thời hạn 5 phút
    otpStorage.set(student_id, {
      otp,
      expires: Date.now() + 5 * 60 * 1000,
    });

    let mailOptions = {
      from: "ht127392@gmail.com",
      to: student.e_mail,
      subject: "Mã OTP lấy lại mật khẩu",
      text: `Mã OTP của bạn là: ${otp}. Mã có hiệu lực trong 5 phút.`,
    };

    await transporter.sendMail(mailOptions);

    // Chuyển sang trang xác nhận OTP, gửi kèm student_id
    let html = fs.readFileSync(
      path.join(
        __dirname,
        "..",
        "Page",
        "Authentication",
        "VerifyOTPReset.html"
      ),
      "utf-8"
    );
    html = html.replace("{{student_id}}", student_id);
    res.send(html);
  } catch (err) {
    console.error(err);
    res.status(500).send("Lỗi máy chủ.");
  }
});

// Xử lý xác nhận OTP
app.post("/verify-otp-reset", (req, res) => {
  const { student_id, otp } = req.body;
  const record = otpStorage.get(student_id);
  if (!record) {
    return res.status(400).send("OTP không tồn tại hoặc đã hết hạn.");
  }
  if (record.expires < Date.now()) {
    otpStorage.delete(student_id);
    return res.status(400).send("OTP đã hết hạn.");
  }
  if (record.otp !== otp) {
    return res.status(400).send("OTP không đúng.");
  }

  // OTP đúng, chuyển đến trang reset password
  otpStorage.delete(student_id);
  let html = fs.readFileSync(
    path.join(__dirname, "..", "Page", "Authentication", "ResetPassword.html"),
    "utf-8"
  );
  html = html.replace(/{{student_id}}/g, student_id);
  res.send(html);
});

// Xử lý cập nhật mật khẩu mới
app.post("/reset-password", async (req, res) => {
  const { student_id, new_password, confirm_password } = req.body;
  if (new_password !== confirm_password) {
    return res.status(400).send("Mật khẩu xác nhận không khớp.");
  }

  try {
    // Cập nhật mật khẩu (bạn có thể mã hóa mật khẩu trước khi lưu)
    await Student.findOneAndUpdate({ student_id }, { pass_word: new_password });
    // Redirect về trang login sau khi đổi mật khẩu thành công
    res.redirect("/");
  } catch (err) {
    console.error(err);
    res.status(500).send("Lỗi cập nhật mật khẩu.");
  }
});

//SearchBox
app.get("/search", async (req, res) => {
  const q = req.query.q;
  try {
    const books = await Book.find({
      title: { $regex: q, $options: "i" },
    });
    res.json(books);
  } catch (err) {
    console.error("Lỗi trong /search:", err);
    res.status(500).send("Lỗi tìm kiếm");
  }
});

//Port
app.listen(PORT, () => {
  console.log(` Server chạy tại http://localhost:${PORT}`);
});
