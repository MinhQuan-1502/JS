const mongoose = require("mongoose");

// URL kết nối MongoDB (thay đổi nếu cần)
const mongoURI = "mongodb://localhost:27017/librarymanagement";

mongoose.connect(mongoURI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});
const db = mongoose.connection;
module.exports = db;
