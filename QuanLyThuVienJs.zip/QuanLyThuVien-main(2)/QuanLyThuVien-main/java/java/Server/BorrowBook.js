const mongoose = require("mongoose");

const borrowBookSchema = new mongoose.Schema({
  date: { type: Date, required: true },
  studentId: {
    type: String,

    required: true,
  },
  bookId: { type: mongoose.Schema.Types.ObjectId, ref: "Book", required: true },
});

module.exports = mongoose.model("BorrowBook", borrowBookSchema);
