const months = [
  "Jan",
  "Feb",
  "Mar",
  "Apr",
  "May",
  "Jun",
  "Jul",
  "Aug",
  "Sep",
  "Oct",
  "Nov",
  "Dec",
];

async function fetchDashboardSummary() {
  try {
    const res = await fetch("http://localhost:3000/api/dashboard/summary");
    const summary = await res.json();

    document.getElementById("total-books").innerText = `📚 Total Books: ${
      summary.totalBooks || 0
    }`;
    document.getElementById("total-members").innerText = `👤 Total Members: ${
      summary.totalMembers || 0
    }`;
    document.getElementById("borrow-today").innerText = `📖 Borrow Today: ${
      summary.borrowToday || 0
    }`;
    document.getElementById("return-today").innerText = `📥 Return Today: ${
      summary.returnToday || 0
    }`;
  } catch (err) {
    console.error("❌ Failed to fetch dashboard summary", err);
  }
}

async function fetchTransactionStats() {
  try {
    const response = await fetch("http://localhost:3000/api/dashboard");
    const data = await response.json();

    const borrowData = Array(12).fill(0);
    const returnData = Array(12).fill(0);

    if (Array.isArray(data.borrow)) {
      data.borrow.forEach((item) => {
        borrowData[item._id - 1] = item.count;
      });
    } else {
      console.warn("data.borrow is not an array", data.borrow);
    }

    if (Array.isArray(data.return)) {
      data.return.forEach((item) => {
        returnData[item._id - 1] = item.count;
      });
    } else {
      console.warn("data.return is not an array", data.return);
    }
    const chart = new ej.charts.Chart({
      background: "#f9f9f9",
      primaryXAxis: { valueType: "Category", title: "Month" },
      primaryYAxis: { visible: false },
      tooltip: {
        enable: true,
        format: "${series.name} in ${point.x} : ${point.y}",
      },
      series: [
        {
          type: "Column",
          name: "Borrow",
          dataSource: months.map((month, i) => ({
            month,
            value: borrowData[i],
          })),
          xName: "month",
          yName: "value",
          fill: "green",
        },
        {
          type: "Column",
          name: "Return",
          dataSource: months.map((month, i) => ({
            month,
            value: returnData[i],
          })),
          xName: "month",
          yName: "value",
          fill: "gray",
        },
      ],
    });

    chart.appendTo("#container-chart");
  } catch (err) {
    console.error("Failed to load chart data", err);
  }
}
fetchDashboardSummary();

fetchTransactionStats();
