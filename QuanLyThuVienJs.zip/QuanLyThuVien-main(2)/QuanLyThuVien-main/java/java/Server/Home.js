//const { render } = require("ejs");

// Load sách khả dụng, hiển thị bảng
function renderBooks(books) {
  const tbody = document.querySelector("#booksTable tbody");
  tbody.innerHTML = "";

  books
    .filter((book) => book.status === "available")
    .forEach((book) => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${book.isbn}</td>
        <td>${book.title}</td>
      `;
      //<td><button class="borrowBtn" data-id="${book._id}" data-isbn="${book.isbn}" data-title="${book.title}">Mượn</button></td>

      tbody.appendChild(tr);
    });

  document.querySelectorAll(".borrowBtn").forEach((btn) => {
    btn.addEventListener("click", () => openBorrowDialog(btn.dataset));
  });
}
async function loadAvailableBooks() {
  try {
    const res = await fetch("/api/books");
    const books = await res.json();
    renderBooks(books);
  } catch (err) {
    alert("Lỗi tải danh sách sách");
    console.error(err);
  }
}

//SearchBox
async function searchBooks(query) {
  try {
    const res = await fetch(`/search?q=${encodeURIComponent(query)}`);

    if (!res.ok) {
      const text = await res.text();
      console.error("Server error:", text);
      return;
    }

    const books = await res.json();
    renderBooks(books);
  } catch (err) {
    console.error("Error searching for books:", err);
  }
}

document.getElementById("searchinput").addEventListener("input", (e) => {
  const query = e.target.value.trim();
  if (query === "") {
    loadAvailableBooks();
  } else {
    searchBooks(query);
  }
});

//Mở dialog mượn sách và điền dữ liệu sách
function openBorrowDialog(bookData) {
  const dialog = document.getElementById("borrowDialog");
  dialog.showModal();

  document.getElementById("bookISBN").value = bookData.isbn;
  document.getElementById("bookTitle").value = bookData.title;
  document.getElementById("bookId").value =
    bookData.id || bookData._id || bookData["id"];

  // Reset form fields except sách
  document.getElementById("date").value = "";
  document.getElementById("studentName").value = "";
}

// Khởi tạo
window.onload = () => {
  loadAvailableBooks();
};
